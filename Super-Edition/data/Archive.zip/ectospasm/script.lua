function onStepHit()
    if curStep == 1 then
        addChromaticAbberationEffect('hud', 0.003)
    end
    if curStep == 1023 then
        addVCREffect('camGame')
        addVCREffect('camHud')
    end
    if curStep == 1151 then
        clearEffects('camGame')
        clearEffects('camHud')
        addChromaticAbberationEffect('hud', 0.003)
    end
    if curStep == 1952 then
        addVCREffect('camGame')
        addVCREffect('camHud')
    end
end